#ifndef SHADER_H
#define SHADER_H

GLuint LoadShaders(const char * vertex_file,const char * fragment_file);

#endif
