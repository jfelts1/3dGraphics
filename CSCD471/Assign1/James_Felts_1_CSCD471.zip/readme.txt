press t to switch between shading types.
