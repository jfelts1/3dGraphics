#ifndef OBJLOADER_H
#define OBJLOADER_H

#include <vector>
#include <glm/glm.hpp>


	class OBJLoader {
	public:
		//! Constructor
		//!
		OBJLoader();

		//! Destructor
		//!
		~OBJLoader();

		//! Execute the reader.
		//!
		//! @param[in] filename The name of the OBJ file to be read.
		//! @return true if the reading succeeded, otherwise false.
		//!
		bool load(const char *filename);

		//! Get the vertices of the 3D model.
		//!
		//! @return An array of vertices.
		//!
		std::vector<glm::vec3> const &getVertices() const;

		//! Get the per-vertex normals of the 3D model.
		//!
		//! @return An array of normal vectors.
		//! 
		std::vector<glm::vec3> const &getNormals() const;

		//! Get the element indices of the 3D model.
		//!
		//! @return An array of element indices.
		//!
		std::vector<uint32_t> const &getVertexIndices() const;
		std::vector<uint32_t> const &getNormalIndices() const;
		std::vector<uint32_t> const &getTextureIndices() const;
		std::vector<glm::vec2> const &getTexCoordinates() const;

		//! Get the per-vertex normals of the 3D model.
		//!
		//! @return An array of normal vectors.
		//! 

		void computeNormals(std::vector<glm::vec3> const &vertices,
			std::vector<uint32_t> const &indices,
			std::vector<glm::vec3> &normals);
	private:
		std::vector<glm::vec3> mVertices;
		std::vector<glm::vec2> mTexCoordinates;
		std::vector<glm::vec3> mNormals;
		std::vector<uint32_t> vIndices;
		std::vector<uint32_t> tIndices;
		std::vector<uint32_t> nIndices;
	};

#endif

