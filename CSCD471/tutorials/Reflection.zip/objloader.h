#ifndef OBJLOADER_H
#define OBJLOADER_H

#include <vector>
#include <glm/glm.hpp>


	class OBJLoader {
	public:
		//! Constructor
		//!
		OBJLoader();

		//! Destructor
		//!
		~OBJLoader();

		//! Execute the reader.
		//!
		//! @param[in] filename The name of the OBJ file to be read.
		//! @return true if the reading succeeded, otherwise false.
		//!
		bool load(const char *filename);

		//! Get the vertices of the 3D model.
		//!
		//! @return An array of vertices.
		//!
		std::vector<glm::vec3> const &getVertices() const;

		//! Get the per-vertex normals of the 3D model.
		//!
		//! @return An array of normal vectors.
		//! 
		std::vector<glm::vec3> const &getNormals() const;
		std::vector<glm::vec2> const &getTexCoordinates() const;

		//! Get the element indices of the 3D model.
		//!
		//! @return An array of element indices.
		//!
		std::vector<int> const &getVertexIndices() const;
		std::vector<int> const &getNormalIndices() const;
		std::vector<int> const &getTextureIndices() const;
		//! Get the per-vertex normals of the 3D model.
		//!
		//! @return An array of normal vectors.
		//! 

		void computeNormals(std::vector<glm::vec3> const &vertices,
			std::vector<int> const &indices,
			std::vector<glm::vec3> &normals);
	private:
		std::vector<glm::vec3> mVertices;
		std::vector<glm::vec2> mTexCoordinates;
		std::vector<glm::vec3> mNormals;
		std::vector<int> vIndices;
		std::vector<int> tIndices;
		std::vector<int> nIndices;
	};

#endif

