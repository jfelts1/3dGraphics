#include <iostream>    // std::cout  
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <string>         // std::string
#include <cstddef>         // std::size_t
#include "objloader.h"


void OBJLoader:: computeNormals(std::vector<glm::vec3> const &vertices, std::vector<int> const &indices, std::vector<glm::vec3> &normals){
		
	    normals.resize(vertices.size(), glm::vec3(0.0f, 0.0f, 0.0f));
		
		// Compute per-vertex normals by averaging the unnormalized face normals
		int vertexIndex0, vertexIndex1, vertexIndex2;
		glm::vec3 normal;
		int numIndices = indices.size();

		
		for (int i = 0; i < numIndices; i += 3) {
			vertexIndex0 = indices[i];
			vertexIndex1 = indices[i + 1];
			vertexIndex2 = indices[i + 2];
			normal = glm::cross(vertices[vertexIndex1] - vertices[vertexIndex0], vertices[vertexIndex2] - vertices[vertexIndex0]);
			normals[vertexIndex0] += normal;
			normals[vertexIndex1] += normal;
			normals[vertexIndex2] += normal;
		}


		int numNormals = normals.size();
		for (int i = 0; i < numNormals; i++) {
			normals[i] = glm::normalize(normals[i]);
		}
}


OBJLoader::OBJLoader() :
mVertices(0),
mNormals(0),
vIndices(0),
nIndices()
{
	std::cout << "Called OBJFileReader constructor" << std::endl;
}

OBJLoader::~OBJLoader()
{
	std::cout << "Called OBJFileReader destructor" << std::endl;
}

bool OBJLoader::load(const char *filename)
{
	// Open OBJ file
	std::ifstream OBJFile(filename);
	if (!OBJFile.is_open()) {
		std::cerr << "Could not open " << filename << std::endl;
		return false;
	}
	
	// Extract vertices and indices
	std::string line;
	glm::vec3 vertex;
	glm::vec2 uv;
        int pIndex;
	while (!OBJFile.eof()) {
		std::getline(OBJFile, line);
		if ((line.find('#') == -1) && (line.find('m') == -1)){
			if (line.find('v') != -1) {

				if ((line.find('t') == -1) && (line.find('n') == -1)){
					std::istringstream vertexLine(line.substr(2));
					vertexLine >> vertex.x;
					vertexLine >> vertex.y;
					vertexLine >> vertex.z;
				    mVertices.push_back(vertex);
				}
				else if ((line.find('t') != -1) && (line.find('n') == -1)){
					std::istringstream texLine(line.substr(3));
					texLine >> uv.x;
					texLine >> uv.y;

					mTexCoordinates.push_back(uv);
				}

			}

			else if (line.find("f ") != -1) {
				std::istringstream faceLine(line);
				std::string val;
				faceLine >> val;

				/********************************
				int val;
				for (int n = 0; n < 3; n++){
					faceLine >> val;	
					vIndices.push_back(val- 1);
					nIndices.push_back(val - 1);
				}
				********************************/
				for (int n = 0; n < 3; n++)
				{
					faceLine >> val;

					
					std::size_t found_first = val.find('/');

					int pIndex0 = atoi(val.substr(0, found_first).c_str());
					
					vIndices.push_back(pIndex0 - 1);
					tIndices.push_back(pIndex0 - 1);
					nIndices.push_back(pIndex0 - 1);

					//std::cout << pIndex0 << " " << pIndex1 << " " << pIndex2 << std::endl;
				}




			}
	    }
	}

	// Close OBJ file
	OBJFile.close();

	// Compute normals
	computeNormals(mVertices, vIndices, mNormals);
	
	
	return true;
}

std::vector<glm::vec3> const &OBJLoader::getVertices() const
{
	return mVertices;
}

std::vector<glm::vec3> const &OBJLoader::getNormals() const
{
	return mNormals;
}

std::vector<glm::vec2> const &OBJLoader::getTexCoordinates() const
{
	return mTexCoordinates;
}

std::vector<int> const &OBJLoader::getVertexIndices() const
{
	return vIndices;
}

std::vector<int> const &OBJLoader::getNormalIndices() const
{
	return nIndices;
}
